//
//  ViewController.m
//  LSTGPUImageDemo
//
//  Created by qqqq on 16/3/21.
//  Copyright © 2016年 LST. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

{
    CGFloat width;
    CGFloat height;
}

@property (nonatomic) UIScrollView *bgScrollView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _bgScrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:_bgScrollView];
    _bgScrollView.backgroundColor = [UIColor whiteColor];
    _bgScrollView.contentSize = CGSizeMake(self.view.frame.size.width, self.view.frame.size.height *10);
    
    width = 150;
    height = 150/0.5625;
    
    //原图片
    UIImage *originImage = [UIImage imageNamed:@"yy"];
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(5, 20, width, height)];
    imageView.image = originImage;
    [_bgScrollView addSubview:imageView];
    
 
    //模糊
    GPUImageBilateralFilter *filter0 = [[GPUImageBilateralFilter alloc] init];
    filter0.blurRadiusInPixels = 2;
    filter0.texelSpacingMultiplier = 5;
    [filter0 forceProcessingAtSize:originImage.size];
    
    GPUImagePicture *stillImageSource = [[GPUImagePicture alloc] initWithImage:originImage];
    [stillImageSource addTarget:filter0];
    [stillImageSource processImage];
    
    [filter0 useNextFrameForImageCapture];
    UIImage *nearImage0 = [filter0 imageByFilteringImage:originImage];
    UIImageView *iv0 = [[UIImageView alloc] initWithImage:nearImage0];
    iv0.frame = CGRectMake(160, 20, width, height);
    [_bgScrollView addSubview:iv0];
    
    //色阶
    GPUImageLevelsFilter *filter1 = [[GPUImageLevelsFilter alloc] init];
    [filter1 setMin:0.156 gamma:1.2 max:0.97];
    [filter1 forceProcessingAtSize:originImage.size];
    [stillImageSource addTarget:filter1];
    [stillImageSource processImage];
    UIImage *nearImage1 = [filter1 imageByFilteringImage:nearImage0];
    UIImageView *iv1 = [[UIImageView alloc] initWithImage:nearImage1];
    iv1.frame = CGRectMake(5, 30+height, width, height);
    [_bgScrollView addSubview:iv1];
    
    //暗灰调
    [self anhuiFilterForImage:nearImage1 andGPUImagePicture:stillImageSource];
    
    //暗冷调
    [self anlengFilterForImage:nearImage1 andGPUImagePicture:stillImageSource];
    
    //暗暖调
    [self annuanFilterForImage:nearImage1 andGPUImagePicture:stillImageSource];
    
    //版画调
    [self banhuaFilterForImage:nearImage1 andGPUImagePicture:stillImageSource];
    
    //报纸调==========
    [self baozhiFilterForImage:nearImage1 andGPUImagePicture:stillImageSource];
    
    //灰色调
    [self huiseFilterForImage:nearImage1 andGPUImagePicture:stillImageSource];
    
    //蓝半调=========
    [self lanbanFilterForImage:nearImage1 andGPUImagePicture:stillImageSource];
    
    //冷色调
    [self lengseFilterForImage:nearImage1 andGPUImagePicture:stillImageSource];
    
    //亮色调
    [self liangseFilterForImage:nearImage1 andGPUImagePicture:stillImageSource];
    
    //暖色调
    [self nuanseFilterForImage:nearImage1 andGPUImagePicture:stillImageSource];
    
    //水彩调
    [self shuicaiFilterForImage:nearImage1 andGPUImagePicture:stillImageSource];
}


#pragma mark - 暗灰调
- (void) anhuiFilterForImage:(UIImage *)image andGPUImagePicture:(GPUImagePicture *)stillImageSource
{
    //饱和度
    GPUImageSaturationFilter *passthroughFilter1 = [[GPUImageSaturationFilter alloc] init];
    passthroughFilter1.saturation = 0;
    [passthroughFilter1 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter1];
    [stillImageSource processImage];
    
    UIImage *nearestNeighborImage1 = [passthroughFilter1 imageByFilteringImage:image];
    
    //明度
    GPUImageBrightnessFilter *passthroughFilter2 = [[GPUImageBrightnessFilter alloc] init];
    passthroughFilter2.brightness = -0.065;
    [passthroughFilter2 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter2];
    [stillImageSource processImage];
    
    UIImage *nearestNeighborImage2 = [passthroughFilter2 imageByFilteringImage:nearestNeighborImage1];
    UIImageView *imageView1 = [[UIImageView alloc] initWithImage:nearestNeighborImage2];
    imageView1.frame = CGRectMake(160, 30+height, width, height);
    [_bgScrollView addSubview:imageView1];
}

#pragma mark - 暗冷调
- (void) anlengFilterForImage:(UIImage *)image andGPUImagePicture:(GPUImagePicture *)stillImageSource
{
   //饱和度
    GPUImageSaturationFilter *passthroughFilter1 = [[GPUImageSaturationFilter alloc] init];
    passthroughFilter1.saturation = 1.21;
    [passthroughFilter1 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter1];
    [stillImageSource processImage];
    
    UIImage *nearestNeighborImage1 = [passthroughFilter1 imageByFilteringImage:image];
    
    //明度
    GPUImageBrightnessFilter *passthroughFilter2 = [[GPUImageBrightnessFilter alloc] init];
    passthroughFilter2.brightness = -0.15;
    [passthroughFilter2 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter2];
    [stillImageSource processImage];
    
    UIImage *nearestNeighborImage2 = [passthroughFilter2 imageByFilteringImage:nearestNeighborImage1];
    
    
    //曲线
    GPUImageToneCurveFilter *passthroughFilter3 = [[GPUImageToneCurveFilter alloc] initWithACV:@"anleng"];
    [passthroughFilter3 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter3];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage3 = [passthroughFilter3 imageByFilteringImage:nearestNeighborImage2];
    UIImageView *imageView1 = [[UIImageView alloc] initWithImage:nearestNeighborImage3];
    imageView1.frame = CGRectMake(5, 50+height*2, width, height);
    [_bgScrollView addSubview:imageView1];

}

#pragma mark - 暗暖调
- (void) annuanFilterForImage:(UIImage *)image andGPUImagePicture:(GPUImagePicture *)stillImageSource
{
    //饱和度
    GPUImageSaturationFilter *passthroughFilter1 = [[GPUImageSaturationFilter alloc] init];
    passthroughFilter1.saturation = 1.21;
    [passthroughFilter1 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter1];
    [stillImageSource processImage];
    
    UIImage *nearestNeighborImage1 = [passthroughFilter1 imageByFilteringImage:image];
    
    //明度
    GPUImageBrightnessFilter *passthroughFilter2 = [[GPUImageBrightnessFilter alloc] init];
    passthroughFilter2.brightness = -0.15;
    [passthroughFilter2 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter2];
    [stillImageSource processImage];
    
    UIImage *nearestNeighborImage2 = [passthroughFilter2 imageByFilteringImage:nearestNeighborImage1];
    
    
    //曲线
    GPUImageToneCurveFilter *passthroughFilter3 = [[GPUImageToneCurveFilter alloc] initWithACV:@"annuan"];
    [passthroughFilter3 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter3];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage3 = [passthroughFilter3 imageByFilteringImage:nearestNeighborImage2];
    UIImageView *imageView1 = [[UIImageView alloc] initWithImage:nearestNeighborImage3];
    imageView1.frame = CGRectMake(160, 50+height*2, width, height);
    [_bgScrollView addSubview:imageView1];
}

#pragma mark - 版画调
- (void) banhuaFilterForImage:(UIImage *)image andGPUImagePicture:(GPUImagePicture *)stillImageSource
{
    //饱和度
    GPUImageSaturationFilter *passthroughFilter1 = [[GPUImageSaturationFilter alloc] init];
    passthroughFilter1.saturation = 0;
    [passthroughFilter1 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter1];
    [stillImageSource processImage];
    
    UIImage *nearestNeighborImage1 = [passthroughFilter1 imageByFilteringImage:image];

    //色阶
    GPUImageLevelsFilter *passthroughFilter2 = [[GPUImageLevelsFilter alloc] init];
    [passthroughFilter2 setMin:0.3 gamma:1 max:0.51];
    [passthroughFilter2 forceProcessingAtSize:image.size];
    [stillImageSource addTarget:passthroughFilter2];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage2 = [passthroughFilter2 imageByFilteringImage:nearestNeighborImage1];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:nearestNeighborImage2];
    imageView.frame = CGRectMake(5, 70+height*3, width, height);
    [_bgScrollView addSubview:imageView];
}

#pragma mark - 报纸调
- (void) baozhiFilterForImage:(UIImage *)image andGPUImagePicture:(GPUImagePicture *)stillImageSource
{
    //饱和度
    GPUImageSaturationFilter *passthroughFilter1 = [[GPUImageSaturationFilter alloc] init];
    passthroughFilter1.saturation = 0;
    [passthroughFilter1 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter1];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage1 = [passthroughFilter1 imageByFilteringImage:image];
    
    GPUImageSobelEdgeDetectionFilter *passthroughFilter2 = [[GPUImageSobelEdgeDetectionFilter alloc] init];
//    passthroughFilter2.sharpness = 1;
    
    [passthroughFilter2 forceProcessingAtSize:image.size];
    [stillImageSource addTarget:passthroughFilter2];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage2 = [passthroughFilter2 imageByFilteringImage:nearestNeighborImage1];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:nearestNeighborImage2];
    imageView.frame = CGRectMake(160, 70+height*3, width, height);
    [_bgScrollView addSubview:imageView];
}

#pragma mark - 灰色调
- (void) huiseFilterForImage:(UIImage *)image andGPUImagePicture:(GPUImagePicture *)stillImageSource
{
    //饱和度
    GPUImageSaturationFilter *passthroughFilter1 = [[GPUImageSaturationFilter alloc] init];
    passthroughFilter1.saturation = 0;
    [passthroughFilter1 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter1];
    [stillImageSource processImage];
    
    UIImage *nearestNeighborImage1 = [passthroughFilter1 imageByFilteringImage:image];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:nearestNeighborImage1];
    imageView.frame = CGRectMake(5, 90+height*4, width, height);
    [_bgScrollView addSubview:imageView];
}

#pragma mark - 蓝半调
- (void) lanbanFilterForImage:(UIImage *)image andGPUImagePicture:(GPUImagePicture *)stillImageSource
{
    //饱和度
    GPUImageSaturationFilter *passthroughFilter1 = [[GPUImageSaturationFilter alloc] init];
    passthroughFilter1.saturation = 0;
    [passthroughFilter1 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter1];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage1 = [passthroughFilter1 imageByFilteringImage:image];
    
    //RGB滤镜
    GPUImageRGBFilter *passthroughFilter2 = [[GPUImageRGBFilter alloc] init];
    
    passthroughFilter2.red = 253/255.0;
    passthroughFilter2.green = 240/255.0;
    passthroughFilter2.blue = 55/255.0;
    
    [passthroughFilter2 forceProcessingAtSize:image.size];
    [stillImageSource addTarget:passthroughFilter2];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage2 = [passthroughFilter2 imageByFilteringImage:nearestNeighborImage1];
    
    GPUImageRGBFilter *passthroughFilter3 = [[GPUImageRGBFilter alloc] init];
    
    passthroughFilter3.red = 36/255.0;
    passthroughFilter3.green = 29/255.0;
    passthroughFilter3.blue = 78/255.0;
    
    [passthroughFilter3 forceProcessingAtSize:image.size];
    [stillImageSource addTarget:passthroughFilter3];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage3 = [passthroughFilter3 imageByFilteringImage:nearestNeighborImage2];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:nearestNeighborImage3];
    imageView.frame = CGRectMake(160, 90+height*4, width, height);
    [_bgScrollView addSubview:imageView];
}

#pragma mark - 冷色调
- (void) lengseFilterForImage:(UIImage *)image andGPUImagePicture:(GPUImagePicture *)stillImageSource
{
    //曲线
    GPUImageToneCurveFilter *passthroughFilter1 = [[GPUImageToneCurveFilter alloc] initWithACV:@"lengse"];
    [passthroughFilter1 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter1];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage1 = [passthroughFilter1 imageByFilteringImage:image];
    UIImageView *imageView1 = [[UIImageView alloc] initWithImage:nearestNeighborImage1];
    imageView1.frame = CGRectMake(5, 110+height*5, width, height);
    [_bgScrollView addSubview:imageView1];
}

#pragma mark - 亮色调
- (void) liangseFilterForImage:(UIImage *)image andGPUImagePicture:(GPUImagePicture *)stillImageSource
{
    //色阶
    GPUImageLevelsFilter *passthroughFilter1 = [[GPUImageLevelsFilter alloc] init];
    [passthroughFilter1 setMin:0.1 gamma:1.2 max:0.7];
    [passthroughFilter1 forceProcessingAtSize:image.size];
    [stillImageSource addTarget:passthroughFilter1];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage1 = [passthroughFilter1 imageByFilteringImage:image];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:nearestNeighborImage1];
    imageView.frame = CGRectMake(160, 110+height*5, width, height);
    [_bgScrollView addSubview:imageView];
}

#pragma mark - 暖色调
- (void) nuanseFilterForImage:(UIImage *)image andGPUImagePicture:(GPUImagePicture *)stillImageSource
{
    //曲线
    GPUImageToneCurveFilter *passthroughFilter1 = [[GPUImageToneCurveFilter alloc] initWithACV:@"nuanse"];
    [passthroughFilter1 forceProcessingAtSize:image.size];
    
    [stillImageSource addTarget:passthroughFilter1];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage1 = [passthroughFilter1 imageByFilteringImage:image];
    UIImageView *imageView1 = [[UIImageView alloc] initWithImage:nearestNeighborImage1];
    imageView1.frame = CGRectMake(5, 130+height*6, width, height);
    [_bgScrollView addSubview:imageView1];
}

#pragma mark - 水彩调
- (void) shuicaiFilterForImage:(UIImage *)image andGPUImagePicture:(GPUImagePicture *)stillImageSource
{
    //色阶
    GPUImageLevelsFilter *passthroughFilter1 = [[GPUImageLevelsFilter alloc] init];
    [passthroughFilter1 setMin:0.35 gamma:0.88 max:0.47];
    [passthroughFilter1 forceProcessingAtSize:image.size];
    [stillImageSource addTarget:passthroughFilter1];
    [stillImageSource processImage];
    UIImage *nearestNeighborImage1 = [passthroughFilter1 imageByFilteringImage:image];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:nearestNeighborImage1];
    imageView.frame = CGRectMake(160, 130+height*6, width, height);
    [_bgScrollView addSubview:imageView];
}

@end
