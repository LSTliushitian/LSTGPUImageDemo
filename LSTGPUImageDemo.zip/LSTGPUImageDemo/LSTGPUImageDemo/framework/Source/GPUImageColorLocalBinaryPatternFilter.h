#import "GPUImage3x3TextureSamplingFilter.h"

@interface GPUImageColorLocalBinaryPatternFilter : GPUImage3x3TextureSamplingFilter

@end
