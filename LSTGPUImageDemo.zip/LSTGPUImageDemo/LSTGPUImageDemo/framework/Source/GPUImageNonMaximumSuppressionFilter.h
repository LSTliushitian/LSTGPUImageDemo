#import "GPUImage3x3TextureSamplingFilter.h"

@interface GPUImageNonMaximumSuppressionFilter : GPUImage3x3TextureSamplingFilter

@end
